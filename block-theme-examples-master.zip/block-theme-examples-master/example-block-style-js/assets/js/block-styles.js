// The CSS for this block style is located in the `style.css` file.
wp.blocks.registerBlockStyle( 'core/image', {
	name: 'hand-drawn',
	label: wp.i18n.__( 'Hand Drawn', 'example-block-style-js' )
} )
